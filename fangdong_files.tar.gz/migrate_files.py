#!/usr/bin/env python3
"""从海外Supabase Storage下载所有文件到本地"""
import os, json, urllib.request, time

OVERSEAS_URL = "https://eszdbwmazsdltngrjjkm.supabase.co"
SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVzemRid21henNkbHRuZ3JqamttIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTgyNzkxMywiZXhwIjoyMDk1NDAzOTEzfQ.mtHDeHDtdwWjXf3qf3SihHfhxk24I-c5qOFtt-RLGk0"
DOMESTIC_API = "https://ruilifangfong.site/rest/v1"
DOMESTIC_KEY = "eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJpc3MiOiAic3VwYWJhc2UiLCAicmVmIjogInRlc3QiLCAicm9sZSI6ICJzZXJ2aWNlX3JvbGUiLCAiaWF0IjogMTc3OTkyOTY1NiwgImV4cCI6IDIwOTU1MDk2NTZ9.J2VWn7aAjtsJim1Ft4UCihd-HPrfI3gStyFxdsMvgas"

UPLOAD_DIR = "/opt/fangdong/uploads"
HEADERS = {"apikey": SERVICE_KEY, "Authorization": f"Bearer {SERVICE_KEY}"}

def api_get(path, params=None):
    url = f"{DOMESTIC_API}/{path}"
    if params:
        import urllib.parse
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        "apikey": DOMESTIC_KEY, "Authorization": f"Bearer {DOMESTIC_KEY}"
    })
    return json.loads(urllib.request.urlopen(req, timeout=15).read())

def download_storage(bucket, path, dest):
    url = f"{OVERSEAS_URL}/storage/v1/object/{bucket}/{path}"
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(resp.read())
        return True
    except Exception as e:
        print(f"  FAIL {bucket}/{path}: {e}")
        return False

def main():
    stats = {"contract-photos": 0, "room-images": 0, "fail": 0}
    
    # 1. 合同照片
    print("=== 迁移合同照片 ===")
    tenants = api_get("tenants", {"select": "id,contract_photos", "contract_photos": "not.is.null", "limit": "200"})
    for t in tenants:
        for p in (t.get("contract_photos") or []):
            dest = os.path.join(UPLOAD_DIR, "contract-photos", p)
            if os.path.exists(dest):
                stats["contract-photos"] += 1
                continue
            if download_storage("contract-photos", p, dest):
                stats["contract-photos"] += 1
            else:
                stats["fail"] += 1
            time.sleep(0.05)
    
    # 2. 房源图片（URL格式不同）
    print("=== 迁移房源图片 ===")
    rooms = api_get("rooms", {"select": "id,images", "images": "not.is.null", "limit": "200"})
    for r in rooms:
        imgs = r.get("images") or ""
        for url in imgs.split(","):
            url = url.strip()
            if not url:
                continue
            # 从URL提取路径
            marker = "/room-images/"
            idx = url.find(marker)
            if idx < 0:
                continue
            path = url[idx + len(marker):]
            dest = os.path.join(UPLOAD_DIR, "room-images", path)
            if os.path.exists(dest):
                stats["room-images"] += 1
                continue
            if download_storage("public/room-images", path, dest):
                stats["room-images"] += 1
            else:
                stats["fail"] += 1
            time.sleep(0.05)
    
    print(f"\n=== 迁移完成 ===")
    print(f"合同照片: {stats['contract-photos']}")
    print(f"房源图片: {stats['room-images']}")
    print(f"失败: {stats['fail']}")

if __name__ == "__main__":
    main()
