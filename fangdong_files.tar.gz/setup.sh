#!/bin/bash
set -e

echo "=== 1. 创建目录 ==="
sudo mkdir -p /opt/fangdong/uploads/{contract-photos,contract-files,room-images}
sudo mkdir -p /opt/fangdong/bin

echo "=== 2. 安装文件服务 ==="
sudo cp file_server.py /opt/fangdong/bin/file_server.py

# 创建systemd服务
sudo tee /etc/systemd/system/fangdong-files.service > /dev/null << 'UNIT'
[Unit]
Description=Fangdong File Server
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/fangdong
ExecStart=/usr/bin/python3 /opt/fangdong/bin/file_server.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable fangdong-files
sudo systemctl restart fangdong-files
sleep 1
echo "文件服务状态:"
sudo systemctl is-active fangdong-files

echo ""
echo "=== 3. 配置nginx ==="
NGINX_CONF="/www/server/panel/vhost/nginx/ruilifangfong.site.conf"

# 在server块中添加upload和files的location（在最后一个}之前插入）
if ! grep -q "location /upload/" "$NGINX_CONF"; then
  # 用sed在最后一个}之前插入
  sudo sed -i '/^}/i\    location /upload/ {\n        proxy_pass http://127.0.0.1:8888/upload/;\n        proxy_set_header Host $host;\n        client_max_body_size 20M;\n        proxy_read_timeout 60s;\n    }\n\n    location /files/ {\n        proxy_pass http://127.0.0.1:8888/files/;\n        proxy_set_header Host $host;\n        expires 30d;\n        add_header Cache-Control "public, immutable";\n    }' "$NGINX_CONF"
  echo "nginx配置已添加"
else
  echo "nginx配置已存在，跳过"
fi

echo ""
echo "=== 4. 测试nginx配置 ==="
sudo nginx -t
sudo nginx -s reload
echo "nginx已重载"

echo ""
echo "=== 5. 测试文件服务 ==="
curl -s -o /dev/null -w "上传测试: HTTP %{http_code}\n" -X POST "http://127.0.0.1:8888/upload/test/hello.txt" -d "hello" -H "Content-Type: text/plain"
curl -s -o /dev/null -w "读取测试: HTTP %{http_code}\n" "http://127.0.0.1:8888/files/test/hello.txt"
curl -s -o /dev/null -w "域名测试: HTTP %{http_code}\n" "https://ruilifangfong.site/files/test/hello.txt"

echo ""
echo "=== 6. 开始迁移文件 ==="
python3 migrate_files.py

echo ""
echo "=== 全部完成 ==="
