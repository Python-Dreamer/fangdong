#!/usr/bin/env python3
"""轻量文件存储服务 - 替代Supabase Storage"""
import os, json, uuid, mimetypes
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import urllib.parse

UPLOAD_DIR = "/opt/fangdong/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class FileHandler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,Authorization,apikey")

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def do_GET(self):
        # /files/bucket/path -> serve file
        parsed = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(parsed.path)
        if path.startswith("/files/"):
            rel = path[len("/files/"):]
            fp = os.path.join(UPLOAD_DIR, rel)
            fp = os.path.normpath(fp)
            if not fp.startswith(UPLOAD_DIR):
                self.send_response(403); self.end_headers(); return
            if os.path.isfile(fp):
                mime, _ = mimetypes.guess_type(fp)
                self.send_response(200)
                self.send_header("Content-Type", mime or "application/octet-stream")
                self.send_header("Cache-Control", "public, max-age=31536000")
                self._cors()
                self.end_headers()
                with open(fp, "rb") as f:
                    self.wfile.write(f.read())
                return
        self.send_response(404); self._cors(); self.end_headers()
        self.wfile.write(b'{"error":"not found"}')

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(parsed.path)
        # /upload/bucket/owner/tenant/timestamp.ext
        if path.startswith("/upload/"):
            rel = path[len("/upload/"):]
            # sanitize
            parts = rel.split("/")
            safe_parts = [p.replace("..","").replace("/","") for p in parts if p]
            if not safe_parts:
                self.send_response(400); self.end_headers(); return
            target_dir = os.path.join(UPLOAD_DIR, *safe_parts[:-1])
            os.makedirs(target_dir, exist_ok=True)
            fname = safe_parts[-1]
            target = os.path.join(target_dir, fname)
            # ensure within UPLOAD_DIR
            target = os.path.normpath(target)
            if not target.startswith(UPLOAD_DIR):
                self.send_response(403); self.end_headers(); return
            # read body directly (binary upload, not multipart)
            length = int(self.headers.get("Content-Length", 0))
            if length > 20 * 1024 * 1024:  # 20MB limit
                self.send_response(413); self.end_headers(); return
            data = self.rfile.read(length)
            with open(target, "wb") as f:
                f.write(data)
            # return path compatible with frontend storage format
            rel_path = "/".join(safe_parts)
            resp = json.dumps({"path": rel_path, "Key": rel_path}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(resp)
            return
        self.send_response(404); self._cors(); self.end_headers()

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(parsed.path)
        if path.startswith("/files/"):
            rel = path[len("/files/"):]
            fp = os.path.join(UPLOAD_DIR, rel)
            fp = os.path.normpath(fp)
            if not fp.startswith(UPLOAD_DIR):
                self.send_response(403); self.end_headers(); return
            try:
                os.remove(fp)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors()
                self.end_headers()
                self.wfile.write(b'{"deleted":true}')
            except FileNotFoundError:
                self.send_response(404); self._cors(); self.end_headers()
                self.wfile.write(b'{"error":"not found"}')
            return
        self.send_response(404); self._cors(); self.end_headers()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8888))
    server = ThreadingHTTPServer(("127.0.0.1", port), FileHandler)
    print(f"File server on http://127.0.0.1:{port}")
    server.serve_forever()
